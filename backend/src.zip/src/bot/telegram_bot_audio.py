import telebot
import time
import asyncio
import edge_tts
import os
from ia.message import processar_mensagem
from ia.audio import transcrever_audio_telegram

def gerar_audio_edge(texto, caminho_ficheiro):
    """Gera um arquivo de áudio usando as vozes da Microsoft."""
    comunicacao = edge_tts.Communicate(text=texto, voice="pt-BR-FranciscaNeural", rate="+10%", pitch="+7Hz")
    asyncio.run(comunicacao.save(caminho_ficheiro))

def iniciar_bot(bot_key):
    bot = telebot.TeleBot(bot_key)

    tipos_nao_suportados = [
        'audio', 'document', 'photo', 'sticker', 'video', 
        'video_note', 'location', 'contact', 'animation'
    ]

    @bot.message_handler(commands=['start'])
    def comando_start(message):
        texto_boas_vindas = (
            "Olá! 👋 Prazer, eu sou a *MIA*, sua assistente inteligente para análise de dados! ✨📊\n\n"
            "Meu trabalho aqui é ajudar a equipe de liderança a planejar nossa produção, garantindo bons resultados. 🛒💚\n\n"
            "Pode conversar comigo do seu jeito, de forma natural, como se estivesse batendo um papo com alguém da equipe! 🧠💬\n\n"
            "Para testar, que tal me perguntar coisas como:\n\n"
            "🍞 _\"MIA, quais produtos precisamos produzir hoje?\"_\n"
            "📈 _\"Quantas unidades devo produzir amanhã?\"_\n\n"
            "Como eu posso facilitar o seu planejamento hoje? 🥰"
        )   
        
        bot.reply_to(message, texto_boas_vindas, parse_mode='Markdown')
    
    @bot.message_handler(content_types=['text'])
    def receber_texto(message):
        print(f"[DEBUG] Mensagem de texto recebida: {message.text}")

        t0 = time.perf_counter()
        msg_temp = bot.reply_to(message, "⏳ <b><i>Processando sua solicitação...</i></b>", parse_mode='HTML')
        
        resposta_bruta = str(processar_mensagem(message.text.lower()))
        resposta = resposta_bruta.replace('[[ ## completed ]]', '').strip()
        
        bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg_temp.message_id,
            text=resposta
        )
        print(f"[TEMPO TEXTO] Processamento completo: {time.perf_counter()-t0:.2f}s")
    
    @bot.message_handler(content_types=['voice'])
    def receber_audio(message):
        msg_temp = bot.reply_to(message, "⏳ <b><i>Ouvindo o seu áudio...</i></b>", parse_mode='HTML')
        
        texto_falado = transcrever_audio_telegram(bot, message)
        
        if 'Desculpe' in texto_falado: 
            texto_temp = f"❗ <i>{texto_falado}</i>"
        else: 
            texto_temp = f"🗣️ <i>Você disse: \"{texto_falado}\"</i>"
            
        bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg_temp.message_id,
            text=f"{texto_temp}\n\n⏳ Processando resposta...",
            parse_mode='HTML'
        )

        print(f"[DEBUG] IA a processar a transcrição...")
        resposta_bruta = str(processar_mensagem(texto_falado.lower()))
        resposta_texto = resposta_bruta.replace('[[ ## completed ]]', '').strip()
        
        bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg_temp.message_id,
            text=f"{texto_temp}\n\n{resposta_texto}",
            parse_mode='HTML'
        )

        ficheiro_audio_saida = f"resposta_{message.chat.id}_{int(time.time())}.ogg"
        
        try:
            print("[ÁUDIO] A gerar resposta de voz da MIA...")
            gerar_audio_edge(resposta_texto, ficheiro_audio_saida)
            
            with open(ficheiro_audio_saida, 'rb') as audio:
                bot.send_voice(
                    chat_id=message.chat.id, 
                    voice=audio,
                    reply_to_message_id=message.message_id 
                )
                
            print("[ÁUDIO] Voz enviada com sucesso!")
            
        except Exception as e:
            print(f"[ERRO ÁUDIO] Falha ao gerar/enviar a resposta falada: {e}")
            
        finally:
            if os.path.exists(ficheiro_audio_saida):
                os.remove(ficheiro_audio_saida)

    @bot.message_handler(content_types=tipos_nao_suportados)
    def receber_formatos_invalidos(message):
        bot.reply_to(
            message, 
            "Desculpe, no momento eu só consigo entender e responder a mensagens de texto ou áudio (voz)!"
        )

    print("[MIA] Bot no ar! Aguardando mensagens no Telegram...")
    bot.infinity_polling(skip_pending=True)