import os
import speech_recognition as sr
from pydub import AudioSegment

def transcrever_audio_telegram(bot, message):
    """
    Baixa a nota de voz do Telegram, converte de OGG para WAV e transcreve para texto.
    """
    id_msg = message.message_id
    chat_id = message.chat.id
    arquivo_ogg = f"temp_voz_{chat_id}_{id_msg}.ogg"
    arquivo_wav = f"temp_voz_{chat_id}_{id_msg}.wav"
    
    texto_transcrito = ""
    
    try:
        print("[ÁUDIO] A baixar a nota de voz...")
        file_info = bot.get_file(message.voice.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        
        with open(arquivo_ogg, 'wb') as new_file:
            new_file.write(downloaded_file)
            
        print("[ÁUDIO] A converter formato para WAV...")
        audio = AudioSegment.from_file(arquivo_ogg, format="ogg")
        audio.export(arquivo_wav, format="wav")
        
        print("[ÁUDIO] A enviar para reconhecimento de voz...")
        reconhecedor = sr.Recognizer()
        with sr.AudioFile(arquivo_wav) as fonte_audio:
            audio_lido = reconhecedor.record(fonte_audio)
            
            texto_transcrito = reconhecedor.recognize_google(audio_lido, language="pt-BR")
            print(f"[ÁUDIO] Transcrição concluída: '{texto_transcrito}'")
            
    except sr.UnknownValueError:
        print("[ERRO ÁUDIO] O Google não conseguiu entender as palavras.")
        texto_transcrito = "Desculpe, não consegui entender o que foi dito no áudio."
    except sr.RequestError as e:
        print(f"[ERRO ÁUDIO] Falha de comunicação com o serviço do Google: {e}")
        texto_transcrito = "Desculpe, estou com problemas de conexão para processar áudios agora."
    except Exception as e:
        print(f"[ERRO ÁUDIO] Erro geral no processamento: {e}")
        texto_transcrito = "Desculpe, ocorreu um erro ao tentar processar a sua mensagem de voz."
        
    finally:
        if os.path.exists(arquivo_ogg):
            os.remove(arquivo_ogg)
        if os.path.exists(arquivo_wav):
            os.remove(arquivo_wav)
            
    return texto_transcrito